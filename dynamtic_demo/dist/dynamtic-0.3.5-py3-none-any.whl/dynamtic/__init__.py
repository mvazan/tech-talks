from .dynamtic import Dynamtic  # noqa: F401
__version__ = "v0.3.5"
