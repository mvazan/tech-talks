import logging
from enum import Enum
from typing import Any, Dict, List, Tuple, get_args

from boto3.dynamodb.types import TypeSerializer
from pydantic import BaseModel, root_validator

from dynamtic.reserved_words import dynamo_db_reserved_words


class DynamticKey(str, Enum):
    """
    Enum class representing the key types in a DynamoDB table.
    """

    PARTITION_KEY = "pk"
    SORT_KEY = "sk"


class IllegalActionException(RuntimeError):
    """
    Custom exception class for illegal actions in the DynamticItem class.
    """

    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


serializer: TypeSerializer = TypeSerializer()


def _is_annotated_with(annotation_value, key_type: DynamticKey) -> bool:
    """
    Check if the given annotation value is annotated with the specified key type.

    :param annotation_value: The annotation value to check.
    :param key_type: The key type to look for (DynamticKey.PARTITION_KEY or DynamticKey.SORT_KEY).
    :return: True if the annotation value is annotated with the key type, False otherwise.
    """
    args = get_args(annotation_value)
    if not args:
        return False
    _, metadata = args
    return metadata == key_type


class DynamticItemMetaClass(type(BaseModel)):
    def __new__(mcls, name, bases, namespace):
        cls = super().__new__(mcls, name, bases, namespace)

        if name == "DynamticItem":
            return cls

        # Raises an exception if the child class has no partition key annotation or more than one.
        pk_count = sum(
            1
            for value in cls.__annotations__.values()
            if _is_annotated_with(value, DynamticKey.PARTITION_KEY)
        )
        if pk_count < 1:
            raise IllegalActionException(
                "Can't instantiate class inherited from DynamticItem class "
                "because it lacks the partition key annotation. "
                "Add Annotated[Any, 'pk'] attribute to it. "
                "(HINT: You can use DynamticKey.PARTITION_KEY enum instead of 'pk')"
            )
        if pk_count > 1:
            raise IllegalActionException(
                "Can't instantiate class inherited from DynamticItem class "
                "because it has more than one partition key annotation. "
                "Ensure that only one attribute is annotated as partition key."
            )

        # Raises an exception if the child class has more than one sort key annotation.
        sk_count = sum(
            1
            for value in cls.__annotations__.values()
            if _is_annotated_with(value, DynamticKey.SORT_KEY)
        )
        if sk_count > 1:
            raise IllegalActionException(
                "Can't instantiate class inherited from DynamticItem class "
                "because it has more than one sort key annotation. "
                "Ensure that only one attribute is annotated as sort key."
            )

        # Raises an exception if the child class contains attribute names restricted by DynamoDB.
        invalid_attribute_names = [
            attribute_key
            for attribute_key in cls.__annotations__.keys()
            if attribute_key.upper() in dynamo_db_reserved_words
        ]

        if len(invalid_attribute_names) > 0:
            raise IllegalActionException(
                "Can't instantiate class inherited from DynamticItem class "
                f"because it contains attribute name{'s' if len(invalid_attribute_names) > 1 else ''} resricted "
                f"by DynamoDB: {', '.join(invalid_attribute_names)}"
            )

        return cls


class DynamticItem(BaseModel, metaclass=DynamticItemMetaClass):
    """
    Base class for creating DynamoDB items using Pydantic.

    This class should not be instantiated directly, but should be subclassed
    with appropriate annotations to describe the DynamoDB record model.
    """

    _logger = logging.getLogger("Dynamtic")

    @root_validator()
    def __compute_origin(cls, values) -> dict:
        """
        Root validator function that validates the input values of a Pydantic model.

        Raises an exception if the class being validated is the base DynamticItem class,
        which should not be instantiated directly since it does not have any annotations.
        Instead, its child classes should implement annotations to describe the DynamoDB record model.

        :param values: The input values for the Pydantic model.
        :return: The validated input values.
        """
        if cls is DynamticItem:
            raise IllegalActionException(
                (
                    "Can't instantiate base DynamticItem class, "
                    "implement child with annotations to describe dynamoDb record model"
                )
            )
        return values

    @classmethod
    def __get_model_attribute_type_by_name(cls, attribute_name: str) -> type:
        """
        Get the model attribute type of a given attribute name in the child class.

        :param attribute_name: The name of the attribute to get the model attribute type for.
        :return: The model attribute type.
        """
        key_type, _ = get_args(cls.__annotations__.get(attribute_name, None))
        return key_type

    @classmethod
    def _get_partition_key(cls) -> str:
        """
        Get the partition key attribute name of the child class.

        :return: The partition key.
        :raises IllegalActionException: If no partition key is found in the child class annotations.
        """
        try:
            return next(
                key
                for key, value in cls.__annotations__.items()
                if _is_annotated_with(value, DynamticKey.PARTITION_KEY)
            )
        except StopIteration as e:
            raise IllegalActionException(
                "No partition key found in class annotations."
            ) from e

    @classmethod
    def _get_sort_key(cls) -> str:
        """
        Get the sort key attribute name of the child class.

        :return: The sort key.
        :raises IllegalActionException: If no sort key is found in the class annotations.
        """
        try:
            return next(
                key
                for key, value in cls.__annotations__.items()
                if _is_annotated_with(value, DynamticKey.SORT_KEY)
            )
        except StopIteration as e:
            raise IllegalActionException(
                "No sort key found in class annotations."
            ) from e

    @classmethod
    def _get_table_key_schema(cls) -> List[Dict[str, str]]:
        """
        Get the table key schema for the child class.

        :return: The table key schema.
        """
        table_key_schema = [
            {"AttributeName": cls._get_partition_key(), "KeyType": "HASH"}
        ]

        try:
            sort_key = cls._get_sort_key()
            table_key_schema.append({"AttributeName": sort_key, "KeyType": "RANGE"})
        except IllegalActionException:
            pass

        return table_key_schema

    @classmethod
    def _get_table_attribute_definitions(cls) -> List[Dict[str, str]]:
        """
        Get the table attribute definitions for the child class.

        :return: The table attribute definitions.
        """

        def extract_key_schema(key: str) -> Dict[str, str]:
            key_type = cls.__get_model_attribute_type_by_name(key)
            dynamo_key_type = list(serializer.serialize(key_type()).keys())[0]
            return {"AttributeName": key, "AttributeType": dynamo_key_type}

        table_key_schema = [extract_key_schema(cls._get_partition_key())]

        try:
            table_key_schema.append(extract_key_schema(cls._get_sort_key()))
        except IllegalActionException:
            pass

        return table_key_schema

    @classmethod
    def _get_table_definition(cls) -> Dict[str, Any]:
        """
        Get the table definition for the child class.

        :return: A dictionary containing the table key schema and attribute definitions.
        """
        return {
            "KeySchema": cls._get_table_key_schema(),
            "AttributeDefinitions": cls._get_table_attribute_definitions(),
        }

    @classmethod
    def get_table_definition(cls, key: DynamticKey) -> Tuple[str, str]:
        """
        Returns the name and type of a table attribute.

        :param key: (DynamticKey) A dynamtic key type used to define an attribute.

        :type key: DynamticKey

        :return: A tuple containing a name and type of the table attribute.

        :rtype: Tuple[str, str]
        """
        return cls._get_cdk_key(key)

    @classmethod
    def _get_cdk_key(cls, dynamtic_key: DynamticKey) -> Tuple[str, str]:
        """
        Get the child class key definition usable in CDK construct.

        :param dynamtic_key: The dynamic key to be used to determine the attribute name and type.
        :type dynamtic_key: DynamticKey
        :return: A tuple containing the attribute name and its corresponding CDK attribute type.
        :rtype: Tuple[str, str]
        """
        key = cls._get_key_attribute(dynamtic_key)
        key_type = cls.__get_model_attribute_type_by_name(key)

        # Mapping Python types to CDK AttributeTypes
        cdk_key_type_mapping = {str: "STRING", int: "NUMBER", bytes: "BINARY"}

        if key_type not in cdk_key_type_mapping:
            raise IllegalActionException(
                f"Unsupported DynamoDB key type {key_type}. Supported types are {list(cdk_key_type_mapping.keys())}."
            )

        return (key, cdk_key_type_mapping[key_type])

    @classmethod
    def _get_expression_attribute(cls, key: str, value, prefix: str = "") -> dict:
        """
        Get the expression attribute for a given key and value.
        E.g.: {':identifier': {'S': 'i123'}} if the key is 'identifier' and the value is 'i123' and prefix is ':'.

        :param key: The key to get the expression attribute for.
        :param value: The value associated with the key.
        :param prefix: An optional prefix for the expression attribute. Default is ''.
        :return: The expression attribute.
        :raises AttributeError: If the type of provided value does not match the type of the key.
        """
        key_type = cls.__get_model_attribute_type_by_name(key)
        if key_type != type(value) and value is not None:
            raise AttributeError(
                f"Type of provided value {type(value)} does not match the type of '{key}': {key_type}"
            )
        return {f"{prefix}{key}": serializer.serialize(value)}

    @classmethod
    def _get_keys(cls) -> List[str]:
        """
        Get the keys (partition key and sort key, if present) of the child class.

        :return: The list of keys.
        """
        keys = [cls._get_partition_key()]

        try:
            sort_key = cls._get_sort_key()
            keys.append(sort_key)
        except IllegalActionException:
            pass

        return keys

    @classmethod
    def _get_key_expression(cls, key: str) -> str:
        """
        Get the key expression for a given key.
        E.g. 'example_key=:example_key' if 'example_key' is the provided key.

        :param key: The key to get the key expression for.
        :return: The key expression.
        """
        return f"{key}=:{key}"

    @classmethod
    def _get_key_attribute(cls, dynamtic_key: DynamticKey):
        """
        Get the partition key or sort key attribute based on the provided dynamic key.

        :param dynamtic_key: The dynamic key used to determine whether to return the partition key or sort key.
        :type dynamtic_key: DynamticKey
        :return: The partition key attribute if the dynamic key is equal to DynamticKey.PARTITION_KEY, otherwise,
         the sort key attribute.
        """
        return (
            cls._get_partition_key()
            if dynamtic_key == DynamticKey.PARTITION_KEY
            else cls._get_sort_key()
        )

    @classmethod
    def _get_key_expression_attribute(
        cls, dynamtic_key: DynamticKey, value, prefix: str = ""
    ):
        """
        Returns the expression attribute for the given dynamic key, value and optional prefix.

        :param dynamtic_key: The dynamic key (partition or sort key).
        :param value: The value of the dynamic key.
        :param prefix: An optional prefix for the expression attribute (default is an empty string).
        :return: The expression attribute as a dictionary.
        :raises AttributeError: If the required sort key value is not provided when it's defined in the model.
        :raises IllegalActionException: If there is no defined sort key in the model but a sort key value is provided.
        """
        key = cls._get_key_attribute(dynamtic_key)
        return cls._get_expression_attribute(key, value, prefix)

    @classmethod
    def _get_partition_key_expression(cls) -> str:
        """
        Returns the partition key expression as a string.

        :return: The partition key expression.
        """
        partition_key = cls._get_partition_key()
        return cls._get_key_expression(partition_key)

    @classmethod
    def _get_partition_key_expression_attribute(cls, value) -> dict:
        """
        Returns the partition key expression attribute as a dictionary.

        :param value: The value of the partition key.
        :return: The partition key expression attribute.
        """
        return cls._get_key_expression_attribute(DynamticKey.PARTITION_KEY, value, ":")

    @classmethod
    def _get_key_expression_attribute_by_keys(
        cls, partition_key_value, sort_key_value=None
    ) -> dict:
        """
        Returns the key expression attribute by partition and sort key values.

        :param partition_key_value: The value of the partition key.
        :param sort_key_value: The value of the sort key (optional).
        :return: The key expression attribute as a dictionary.
        :raises AttributeError: If the required sort key value is not provided when it's defined in the model.
        :raises IllegalActionException: If there is no defined sort key in the model but a sort key value is provided.
        """
        result = cls._get_key_expression_attribute(
            DynamticKey.PARTITION_KEY, partition_key_value
        )

        try:
            sort_key_expression_attribute = cls._get_key_expression_attribute(
                DynamticKey.SORT_KEY, sort_key_value
            )
            if sort_key_value is None:
                raise AttributeError(
                    "The required sort key value is not provided. "
                    f"The '{cls.__name__}' model has its defined sort key, '{cls._get_sort_key()}'. "
                    "Please pass the sort key value for it."
                )

            result.update(sort_key_expression_attribute)
        except IllegalActionException:
            if sort_key_value is not None:
                cls._logger.warning(
                    f"There is no defined sort key in the '{cls.__name__}' "
                    f"so the provided sort key value '{sort_key_value}' is ignored."
                )

        return result

    def _get_identification(self) -> dict:
        """
        Returns the identification attributes as a dictionary.
        E.g. {"identifier": {"S": "i123"}, "insurance_number" : {"N": "30"}} if identifier is partition key
         and insurance_number is sort key.

        :return: The identification attributes.
        """
        key_attributes = self._get_keys()
        return {
            k: serializer.serialize(v)
            for k, v in self.dict().items()
            if k in key_attributes
        }

    @classmethod
    def _get_identification_by_keys(
        cls, partition_key_value, sort_key_value=None
    ) -> dict:
        """
        Returns the identification attributes by partition and sort key values.
        E.g. {"identifier": {"S": "i123"}, "insurance_number" : {"N": "30"}} if identifier is partition key
         and insurance_number is sort key.

        :param partition_key_value: The value of the partition key.
        :param sort_key_value: The value of the sort key (optional).
        :return: The identification attributes as a dictionary.
        """
        return cls._get_key_expression_attribute_by_keys(
            partition_key_value, sort_key_value
        )

    def _get_update_expression(self) -> str:
        """
        Returns the update expression as a string.
        E.g. "SET first_name=:first_name, shoe_size=:shoe_size" if first_name and shoe_size are the attributes.

        :return: The update expression.
        """
        attributes = [
            self._get_key_expression(attribute_key)
            for attribute_key, attribute_value in self.dict().items()
            if attribute_value is not None and attribute_key not in self._get_keys()
        ]
        return "SET " + ", ".join(attributes)

    def _get_update_expression_attributes(self) -> dict:
        """
        Returns the update expression attributes as a dictionary.
        E.g. {
            ":identifier": {'S': "i123"},
            ":insurance_number": {"N": "30"},
            ":first_name": {"S": "Alice"},
            ":shoe_size": {"N": "8"}
        }
        if identifier is partition key and insurance_number is sort key and first_name and shoe_size are the attributes.

        :return: The update expression attributes.
        """
        return {
            f":{attribute_key}": serializer.serialize(attribute_value)
            for attribute_key, attribute_value in self.dict().items()
            if attribute_value is not None and attribute_key not in self._get_keys()
        }
