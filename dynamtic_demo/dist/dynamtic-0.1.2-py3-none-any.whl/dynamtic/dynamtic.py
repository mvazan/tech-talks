import logging
from json import dumps as json_dumps
from typing import Any, Callable, Generic, List, Tuple, Type, TypeVar, Union

from boto3 import client
from boto3.dynamodb.types import TypeDeserializer, TypeSerializer
from botocore.exceptions import ClientError
from botocore.paginate import PageIterator
from dynamtic.models.dynamtic_item import DynamticItem

logging.getLogger().setLevel(logging.INFO)
T = TypeVar("T", bound=DynamticItem)


class Dynamtic(Generic[T]):
    """
    A generic class for interacting with AWS DynamoDB tables using boto3.

    Attributes:
        __dynamtic_item_type (Type[T]): The type of the DynamoDB item.
        client (boto3.client): The boto3 DynamoDB client.
        table_name (str): The name of the DynamoDB table.
        serializer (TypeSerializer): Serializer for DynamoDB types.
        deserializer (TypeDeserializer): Deserializer for DynamoDB types.
    """

    def __init__(
        self,
        dynamtic_item_type: Type[T],
        table_name: str,
        region_name: str = "us-east-1",
    ):
        """
        Initializes the Dynamtic class with the given parameters.

        Args:
            dynamtic_item_type (Type[T]): The type of the DynamoDB item.
            table_name (str): The name of the DynamoDB table.
            region_name (str, optional): The AWS region. Defaults to "us-east-1".
        """
        self.__dynamtic_item_type = dynamtic_item_type
        self.client = client("dynamodb", region_name=region_name)
        self.table_name = table_name
        self.serializer = TypeSerializer()
        self.deserializer = TypeDeserializer()

    def __log_and_execute(
        self,
        func: Callable,
        action: Tuple[str, str],
        item: Union[DynamticItem, str, Tuple[Any, Any], None] = None,
    ):
        try:
            log_message = f"{action[0]} '{self.__dynamtic_item_type.__name__}' {action[1]} '{self.table_name}' table"

            if item is None:
                log_message += "."
                func_args = []
            elif isinstance(item, DynamticItem):
                log_message += f": {json_dumps(item.dict(), indent=4)}"
                func_args = [item]
            elif isinstance(item, Tuple):
                pk, sk = item
                log_message += f": PK: {pk}{f', SK: {sk}' if sk else '.'}"
                func_args = [pk, sk]
            else:
                log_message += f": '{item}'"
                func_args = [item]

            logging.info(log_message)
            return func(*func_args)
        except Exception as e:
            logging.error(
                f"{action[0]} '{self.__dynamtic_item_type.__name__}' {action[1]} '{self.table_name}' "
                f"table failed: {str(e)}"
            )
            raise

    def __parse_dynamic_item(self, item: dict):
        return self.__dynamtic_item_type.parse_obj(
            {k: self.deserializer.deserialize(v) for k, v in item.items()}
        )

    def __process_pages(self, page_iterator: PageIterator) -> List[T]:
        items = []

        for index, page in enumerate(page_iterator, start=1):
            logging.debug(f"Returning {index}. page of '{self.table_name}' table.")
            items.extend(
                [self.__parse_dynamic_item(item) for item in page.get("Items", [])]
            )

        return items

    def put(self, item: DynamticItem) -> None:
        """
        Put an item into the DynamoDB table.

        Args:
            item (DynamticItem): The item to be inserted.
        """

        def create_func(item: DynamticItem):
            self.client.put_item(
                TableName=self.table_name,
                Item={k: self.serializer.serialize(v) for k, v in item.dict().items()},
            )

        self.__log_and_execute(create_func, ("Creating", "in"), item)

    def get(self, partition_key_value, sort_key_value=None) -> T:
        """
        Get an item from the DynamoDB table using partition key and optional sort key.

        Args:
            partition_key_value (Any): The value of the partition key.
            sort_key_value (Any, optional): The value of the sort key. Defaults to None.

        Returns:
            T: The retrieved item as an instance of the specified type.
        """

        def read_func(partition_key_value, sort_key_value=None) -> T:
            response = self.client.get_item(
                TableName=self.table_name,
                Key=self.__dynamtic_item_type._get_identification_by_keys(
                    partition_key_value, sort_key_value
                ),
            )

            if "Item" not in response:
                raise ClientError(
                    {
                        "Error": {
                            "Code": "ResourceNotFoundException",
                            "Message": (
                                f"Item '{self.__dynamtic_item_type.__name__}' "
                                f"not found in table '{self.table_name}'. "
                                f"Used PK: {partition_key_value}"
                                f"{f', SK: {sort_key_value}' if sort_key_value is not None else ''}"
                            ),
                        }
                    },
                    "GetItem",
                )

            return self.__parse_dynamic_item(response.get("Item"))

        return self.__log_and_execute(
            read_func,
            ("Reading", "from"),
            (
                partition_key_value,
                sort_key_value,
            ),
        )

    def update(self, item: DynamticItem) -> None:
        """
        Update an item in the DynamoDB table.

        Args:
            item (DynamticItem): The item with updated values.
        """

        def update_func(item: DynamticItem):
            self.client.update_item(
                TableName=self.table_name,
                Key=item._get_identification(),
                UpdateExpression=item._get_update_expression(),
                ExpressionAttributeValues=item._get_update_expression_attributes(),
            )

        self.__log_and_execute(update_func, ("Updating", "in"), item)

    def delete(self, partition_key_value, sort_key_value=None) -> None:
        """
        Delete an item from the DynamoDB table using partition key and optional sort key.

        Args:
            partition_key_value (Any): The value of the partition key.
            sort_key_value (Any, optional): The value of the sort key. Defaults to None.
        """

        def delete_func(partition_key_value, sort_key_value=None):
            self.client.delete_item(
                TableName=self.table_name,
                Key=self.__dynamtic_item_type._get_identification_by_keys(
                    partition_key_value, sort_key_value
                ),
            )

        self.__log_and_execute(
            delete_func, ("Deleting", "from"), (partition_key_value, sort_key_value)
        )

    def scan(self) -> List[T]:
        """
        Scan the entire DynamoDB table and return all items as a list.

        Returns:
            List[T]: A list of all items in the table as instances of the specified type.
        """

        def scan_func():
            paginator = self.client.get_paginator("scan")
            page_iterator = paginator.paginate(TableName=self.table_name)
            return self.__process_pages(page_iterator)

        return self.__log_and_execute(scan_func, ("Scan", "from"))

    def query_by_partition_key(self, partition_key_value) -> List[T]:
        """
        Query the DynamoDB table by partition key and return matching items as a list.

        Args:
            partition_key_value (Any): The value of the partition key.

        Returns:
            List[T]: A list of matching items as instances of the specified type.
        """

        def query_by_partition_key_func(partition_key_value):
            paginator = self.client.get_paginator("query")
            page_iterator = paginator.paginate(
                TableName=self.table_name,
                KeyConditionExpression=self.__dynamtic_item_type._get_partition_key_expression(),
                ExpressionAttributeValues=self.__dynamtic_item_type._get_partition_key_expression_attribute(
                    partition_key_value
                ),
            )
            return self.__process_pages(page_iterator)

        return self.__log_and_execute(
            query_by_partition_key_func,
            ("Query by partition key", "from"),
            partition_key_value,
        )
